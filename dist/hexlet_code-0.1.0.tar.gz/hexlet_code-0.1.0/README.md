### Hexlet tests and linter status:
[![Actions Status](https://github.com/UnJIeashed/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/UnJIeashed/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/5fb9254d02c6a07e2ca9/maintainability)](https://codeclimate.com/github/UnJIeashed/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/jU2PquC7CR0aYEroJssKuz4ID.svg)](https://asciinema.org/a/jU2PquC7CR0aYEroJssKuz4ID)
[![asciicast](https://asciinema.org/a/7z1J0d8Lg1O8dDwn7qZDwnsB5.svg)](https://asciinema.org/a/7z1J0d8Lg1O8dDwn7qZDwnsB5)
[![asciicast](https://asciinema.org/a/vTA3falJGYvMCnfOxI2cWNExW.svg)](https://asciinema.org/a/vTA3falJGYvMCnfOxI2cWNExW)
[![asciicast](https://asciinema.org/a/fpeRO1YHSHoRvkGy7jwNBhsAB.svg)](https://asciinema.org/a/fpeRO1YHSHoRvkGy7jwNBhsAB)
[![asciicast](https://asciinema.org/a/ki2PcyYa3szY77rpld6BG08KH.svg)](https://asciinema.org/a/ki2PcyYa3szY77rpld6BG08KH)
